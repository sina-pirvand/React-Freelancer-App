import DashboardLayout from "../features/freelancer/DashboardLayout";

const FreelancerDashboard = () => {
  return (
    <div>
      <DashboardLayout />
    </div>
  );
};

export default FreelancerDashboard;
