import DashboardLayout from "../features/admin/DashboardLayout";

const AdminDashboard = () => {
  return (
    <div>
      <DashboardLayout />
    </div>
  );
};

export default AdminDashboard;
