import CompleteProfileForm from "../features/auth/CompleteProfileForm";

const CompleteProfile = () => {
  return (
    <div className="container xl:max-w-screen-xl">
      <div>
        <CompleteProfileForm />
      </div>
    </div>
  );
};

export default CompleteProfile;
