const Home = () => {
  return (
    <div className="container xl:max-w-screen-xl">
      <div>Home</div>
    </div>
  );
};

export default Home;
