import DashboardLayout from "../features/owner/DashboardLayout";

const OwnerDashboard = () => {
  return (
    <div>
      <DashboardLayout />
    </div>
  );
};

export default OwnerDashboard;
