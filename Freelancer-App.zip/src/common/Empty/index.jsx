const Empty = ({ resourceName }) => {
  return <p className="p-4 text-secondary-500">{resourceName} یافت نشد</p>;
};

export default Empty;
